#!/usr/bin/env bash

set -e
set -u

source common_ec2.sh

tpcc_ec2_iteration() {
    restore_postgres $postgres_host

    if [[ $1 == "pgbouncer" ]]; then
        start_pgbouncer
    elif [[ $1 == "odyssey" ]]; then
        start_odyssey
    elif [[ $1 == "mpbouncer" ]]; then
        start_mp_bouncer
    fi

    if [[ $1 == "none" ]]; then
        run_benchbase $workload "/home/ubuntu/run_${workload}_postgres.xml" "postgres"
    else
        run_benchbase $workload "/home/ubuntu/run_${workload}_proxy.xml" "postgres"
    fi

    get_benchbase_raw $3 $1 $2 "postgres"

    if [[ $1 == "pgbouncer" ]]; then
        stop_pgbouncer
    elif [[ $1 == "odyssey" ]]; then
        stop_odyssey
    elif [[ $1 == "mpbouncer" ]]; then
        stop_mp_bouncer
    fi
    
    stop_postgres $postgres_host
}

main() {
    # set_up_servers

    stop_postgres $postgres_host

    get_mp_bouncer bouncer2 bench
    send_file $bouncer_host mpbouncer.ini mpbouncer.ini
    change_mp_bouncer_pool_mode "transaction"
    build_mp_bouncer

    get_odyssey
    build_odyssey
    send_file $bouncer_host odyssey_tcp.conf odyssey/odyssey.conf

    get_pgbouncer
    build_pgbouncer
    send_file $bouncer_host pgbouncer_tcp.ini pgbouncer.ini

    get_benchbase "587b74f"
    build_benchbase "postgres"

    start_postgres $postgres_host
    load_benchbase "tpcc" "/home/ubuntu/load_tpcc_postgres.xml" "postgres"
    back_up_postgres $postgres_host

    rm -r results || true
    mkdir -p results

    for workload in "tpcc"
    do        
        for bouncer in "none" "pgbouncer" "odyssey" "mpbouncer"
        do
            for iteration in 0
            do
                tpcc_ec2_iteration $bouncer $iteration $workload
            done # end iteration loop
        done # end bouncer loop
    done # end workload loop
}

main
