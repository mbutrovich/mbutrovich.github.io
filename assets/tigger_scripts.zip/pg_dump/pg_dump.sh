#!/usr/bin/env bash

set -e
set -u

source common_ec2.sh

output_file=pg_dump.csv

pg_dump_iteration() {
    restore_postgres $postgres_host

    if [[ $1 == "pgbouncer" ]]; then
        start_pgbouncer
    elif [[ $1 == "odyssey" ]]; then
        start_odyssey
    elif [[ $1 == "mpbouncer" ]]; then
        start_mp_bouncer
    fi

    if [[ $1 == "none" ]]; then
        run_pg_dump $postgres_host $postgres_port
    else
        run_pg_dump $bouncer_host $bouncer_port
    fi

    if [[ $1 == "pgbouncer" ]]; then
        stop_pgbouncer
    elif [[ $1 == "odyssey" ]]; then
        stop_odyssey
    elif [[ $1 == "mpbouncer" ]]; then
        stop_mp_bouncer
    fi
    stop_postgres $postgres_host
}

main() {
    set_up_servers

    stop_postgres $postgres_host

    get_mp_bouncer bouncer_64bit bench_test_64bit
    send_file $bouncer_host mpbouncer.ini mpbouncer.ini
    change_mp_bouncer_pool_mode "session"
    build_mp_bouncer

    get_odyssey
    build_odyssey
    send_file $bouncer_host odyssey_tcp.conf odyssey/odyssey.conf

    get_pgbouncer
    build_pgbouncer
    send_file $bouncer_host pgbouncer_tcp.ini pgbouncer.ini

    start_postgres $postgres_host
    run_postgres_script "/home/ubuntu/tables.sql"
    back_up_postgres $postgres_host

    rm $output_file || true
    write_csv_line "bouncer,iteration,time" $output_file

    for bouncer in "none" "pgbouncer" "odyssey" "mpbouncer"
    do
        for iteration in 0 1 2 3 4
        do
            pg_dump_iteration $bouncer
            write_csv_line "$bouncer,$iteration,$pg_dump_time" $output_file
        done # end iteration loop
    done # end bouncer loop
}

main
