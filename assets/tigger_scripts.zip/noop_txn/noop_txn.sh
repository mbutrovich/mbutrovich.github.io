#!/usr/bin/env bash

set -e
set -u

source common.sh

postgres_host=dev10.db.pdl.local.cmu.edu
postgres_port=5432
bouncer_host=dev10.db.pdl.local.cmu.edu
bouncer_port=6432
output_file=noop_txn.csv

noop_iteration() {
    start_postgres
    if [[ $1 == "pgbouncer_unix" ]]; then
        send_file $bouncer_host pgbouncer_unix.ini pgbouncer.ini
        start_pgbouncer
    elif [[ $1 == "pgbouncer_tcp" ]]; then
        send_file $bouncer_host pgbouncer_tcp.ini pgbouncer.ini
        start_pgbouncer
    elif [[ $1 == "odyssey_unix" ]]; then
        send_file $bouncer_host odyssey_unix.conf odyssey/odyssey.conf
        start_odyssey
    elif [[ $1 == "odyssey_tcp" ]]; then
        send_file $bouncer_host odyssey_tcp.conf odyssey/odyssey.conf
        start_odyssey
    elif [[ $1 == "mpbouncer" ]]; then
        send_file $bouncer_host mpbouncer.ini mpbouncer.ini
        start_mp_bouncer
    fi

    if [[ $1 == "none" ]]; then
        run_benchbase "noop" "/home/mbutrovi/noop_postgres.xml"
    else
        run_benchbase "noop" "/home/mbutrovi/noop_proxy.xml"
    fi

    get_benchbase_txns

    if [[ $1 == "pgbouncer_unix" ]]; then
        stop_pgbouncer
    elif [[ $1 == "pgbouncer_tcp" ]]; then
        stop_pgbouncer
    elif [[ $1 == "odyssey_unix" ]]; then
        stop_odyssey
    elif [[ $1 == "odyssey_tcp" ]]; then
        stop_odyssey
    elif [[ $1 == "mpbouncer" ]]; then
        stop_mp_bouncer
    fi
    stop_postgres
}

main() {
    set_up_servers

    stop_postgres

    get_mp_bouncer
    send_file $bouncer_host mpbouncer.ini mpbouncer.ini
    change_mp_bouncer_pool_mode "transaction"
    build_mp_bouncer

    get_odyssey
    build_odyssey

    get_pgbouncer
    build_pgbouncer

    get_benchbase "587b74f"
    build_benchbase

    rm $output_file || true
    write_csv_line "bouncer,iteration,total" $output_file

    for bouncer in "none" "pgbouncer_unix" "pgbouncer_tcp" "odyssey_unix" "odyssey_tcp" "mpbouncer"
    do
        for iteration in 0 1 2 3 4
        do
            noop_iteration $bouncer
            write_csv_line "$bouncer,$iteration,$benchbase_txns" $output_file
        done # end iteration loop
    done # end bouncer loop
}

main
