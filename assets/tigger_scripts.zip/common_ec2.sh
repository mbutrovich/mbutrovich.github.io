#!/usr/bin/env bash

set -e # Stop the script on non-zero return value from command.
set -u # Stop the script if there are any unset referenced variables.

########################################
### Environment
########################################

postgres_host=ip-172-31-40-33.us-east-2.compute.internal
postgres_port=5432
bouncer_host=ip-172-31-41-214.us-east-2.compute.internal
bouncer_port=6432
mirror_host=ip-172-31-17-118.us-east-2.compute.internal

tune_network() {
    # https://github.com/amzn/amzn-drivers/blob/master/kernel/linux/ena/ENA_Linux_Best_Practices.rst
    # https://www.kernel.org/doc/html/latest/networking/scaling.html
    sudo ethtool -C ens5 adaptive-rx on     # enable adaptive interrupt algorithm
    sudo ethtool -G ens5 rx 2048            # increase receive queue size
    sudo ethtool -L ens5 combined 1
}

install_dependencies() {
    sudo apt update
    sudo apt install pkg-config automake m4 libtool libevent-dev libbpf-dev make libssl-dev clang build-essential linux-tools-generic linux-cloud-tools-generic xmlstarlet python3-pip linux-tools-aws csvkit sysstat
    pip install psycopg
}

# Any machine or OS-specific things to change before running experiments.
set_up_servers() {
    # ssh -i "aws2022.pem" $postgres_host 'sudo cpupower frequency-set --governor performance > /dev/null'
    # ssh -i "aws2022.pem" $bouncer_host 'sudo cpupower frequency-set --governor performance > /dev/null'
    # sudo cpupower frequency-set --governor performance > /dev/null
    # ulimit -n 65535 # edit /etc/security/limits.conf instead
    ssh -i "aws2022.pem" $bouncer_host 'sudo ethtool -C ens5 adaptive-rx on > /dev/null'
    ssh -i "aws2022.pem" $bouncer_host 'sudo ethtool -G ens5 rx 2048 > /dev/null'
    ssh -i "aws2022.pem" $bouncer_host 'sudo ethtool -L ens5 combined 1 > /dev/null'
}

send_file() {
    scp -i "aws2022.pem" $2 ubuntu@$1:./$3
}

send_remote_file() {
    ssh -i "aws2022.pem" ${1} "scp -i "aws2022.pem" ${3} ubuntu@${2}:./${4}"
}

process_is_running() {
    # Temporarily disable exit on non-zero return code, since we rely on it from pg_isready.
    set +e
    sudo kill -0 $1
    is_running=$?
    set -e
}

install_bcc() {
    sudo apt update
    sudo apt install -y bison build-essential cmake flex git libedit-dev \
        libllvm14 llvm-14-dev libclang-14-dev python3 zlib1g-dev libelf-dev libfl-dev python3-distutils
    git clone https://github.com/iovisor/bcc.git
    cd bcc && git checkout tags/v0.25.0
    mkdir build; cd build
    cmake ..
    make -j
    sudo make install
    cmake -DPYTHON_CMD=python3 .. # build python3 binding
    pushd src/python/
    make -j
    sudo make install
    popd
}

start_profile() {
    ssh -i "aws2022.pem" -f $bouncer_host 'nohup sudo perf record -F 99 -a -g -q > /dev/null 2> /dev/null < /dev/null &'
}

stop_profile() {
    ssh -i "aws2022.pem" $bouncer_host 'sudo pkill -2 -of perf && sleep 5'
    ssh -i "aws2022.pem" $bouncer_host "sudo perf script -i perf.data > ${1}"
}

start_cpu_utilization() {
    ssh -i "aws2022.pem" -f $bouncer_host "nohup sudo sar -u ALL 1 ${1} > ${2} &"
}

stop_cpu_utilization() {
    ssh -i "aws2022.pem" $bouncer_host 'sudo pkill -2 -ox sar'
}

########################################
### PostgreSQL
########################################

# Calls pg_isready and stores the return value in $pgready.
# See https://www.postgresql.org/docs/current/app-pg-isready.html for return value details.
postgres_is_running() {
    # Temporarily disable exit on non-zero return code, since we rely on it from pg_isready.
    set +e
    pg_isready -h $1 -p $postgres_port -d benchbase -U mbutrovi -q
    pgready=$?
    set -e
}

# Start postgres and sleep until it is accepting connections.
start_postgres() {
    postgres_is_running $1
    ssh -i "aws2022.pem" $1 'sudo systemctl start postgresql || true'
    while [ $pgready -gt 0 ]
    do
        sleep 10
        postgres_is_running $1
    done
}

# Stop postgres and sleep until it is no longer accepting connections.
stop_postgres() {
    postgres_is_running $1
    ssh -i "aws2022.pem" $1 'sudo systemctl stop postgresql || true'
    while [ $pgready -ne 2 ]
    do
        sleep 10
        postgres_is_running $1
    done
}

# Removes any existing archive, stops postgres, archives the data folder, and restarts postgres.
back_up_postgres() {
    ssh -i "aws2022.pem" $1 'sudo rm postgres_data.tar || true'
    stop_postgres $1
    ssh -i "aws2022.pem" $1 'sudo tar -cvf postgres_data.tar -C /var/lib/postgresql . > /dev/null'
    start_postgres $1
}

# Stops postgres, removes the data folder, unarchives the backup, and restarts postgres.
restore_postgres() {
    stop_postgres $1
    ssh -i "aws2022.pem" $1 'sudo rm -r /var/lib/postgresql/* || true'
    ssh -i "aws2022.pem" $1 'sudo tar -xvf postgres_data.tar -C /var/lib/postgresql > /dev/null'
    start_postgres $1
    psql "host=$postgres_host port=$postgres_port dbname=benchbase sslmode=disable user=mbutrovi" --command="VACUUM FULL;"
}

install_postgres() {
    sudo apt update
    sudo apt -y install postgresql-14

    # Drop the existing default cluster
    sudo pg_dropcluster --stop 14 main

    # Chad said this is already created, just not set to automount. I found old data in it on dev10
    sudo mount /mnt/nvme0n1

    # Create the new cluster's data folder, then create the cluster
    sudo mkdir -p /mnt/nvme0n1/postgresql/data
    sudo chmod 0750 /mnt/nvme0n1/postgresql/data

    sudo pg_createcluster --datadir=/mnt/nvme0n1/postgresql/data --port=5432 --start 14 main


    # Create the user we need
    sudo -u postgres psql -c "create user mbutrovi with superuser encrypted password 'password';"

    sudo pg_ctlcluster stop 14 main

    # change listen_addresses in postgresql.conf
    # change authentication in pg_hba.conf
    # change pgtune params in postgresql.conf

    sudo pg_ctlcluster start 14 main

    # psql postgresl and create database benchbase
}

uninstall_postgres() {
    sudo apt-get --purge remove postgresql\*
    sudo rm -r /etc/postgresql/
    sudo rm -r /etc/postgresql-common/
    sudo rm -r /var/lib/postgresql/
    sudo userdel -r postgres
    sudo groupdel postgres
}

run_postgres_script() {
    psql "host=$postgres_host port=$postgres_port dbname=benchbase sslmode=disable user=mbutrovi" --file=$1
}

########################################
### mpbouncer
########################################

get_mp_bouncer() {
    ssh -i "aws2022.pem" $bouncer_host 'sudo rm -r mpbouncer bouncer || true'

    ssh -i "aws2022.pem" $bouncer_host 'git clone https://github.com/mbutrovich/mpbouncer.git'
    ssh -i "aws2022.pem" $bouncer_host "cd mpbouncer && git checkout ${1}"
    ssh -i "aws2022.pem" $bouncer_host 'cd mpbouncer && git submodule init'
    ssh -i "aws2022.pem" $bouncer_host 'cd mpbouncer && git submodule update'
    ssh -i "aws2022.pem" $bouncer_host 'cd mpbouncer && chmod +x *.sh lib/*.sh lib/mk/*.sh'
    ssh -i "aws2022.pem" $bouncer_host 'cd mpbouncer && ./autogen.sh'
    ssh -i "aws2022.pem" $bouncer_host 'cd mpbouncer && ./configure LIBS="-lbpf"'

    ssh -i "aws2022.pem" $bouncer_host 'git clone https://github.com/mbutrovich/bouncer.git'
    ssh -i "aws2022.pem" $bouncer_host "cd bouncer && git checkout ${2}"
    ssh -i "aws2022.pem" $bouncer_host 'chmod +x bouncer/*.sh'
}

build_mp_bouncer() {
    ssh -i "aws2022.pem" $bouncer_host 'cd mpbouncer && make clean'
    ssh -i "aws2022.pem" $bouncer_host 'cd mpbouncer && make -j pgbouncer'

    ssh -i "aws2022.pem" $bouncer_host 'cd bouncer && make clean'
    ssh -i "aws2022.pem" $bouncer_host 'cd bouncer && make -j'
}

change_bpf_pool_size() {
    ssh -i "aws2022.pem" $bouncer_host "sed -i '/bpf_pool_size = [0-9]*/c\ bpf_pool_size = $1' mpbouncer.ini"
}

change_mp_bouncer_pool_mode() {
    if [[ $1 == "session" ]]; then
        ssh -i "aws2022.pem" $bouncer_host "sed -i '/pool_mode = /c\ pool_mode = session' mpbouncer.ini"
        ssh -i "aws2022.pem" $bouncer_host "sed -i '/const volatile int pooling_mode = /c\const volatile int pooling_mode = SESSION_POOLING;' bouncer/client.bpf.c"
        ssh -i "aws2022.pem" $bouncer_host "sed -i '/const volatile int pooling_mode = /c\const volatile int pooling_mode = SESSION_POOLING;' bouncer/server.bpf.c"
    elif [[ $1 == "transaction" ]]; then
        ssh -i "aws2022.pem" $bouncer_host "sed -i '/pool_mode = /c\ pool_mode = transaction' mpbouncer.ini"
        ssh -i "aws2022.pem" $bouncer_host "sed -i '/const volatile int pooling_mode = /c\const volatile int pooling_mode = TRANSACTION_POOLING;' bouncer/client.bpf.c"
        ssh -i "aws2022.pem" $bouncer_host "sed -i '/const volatile int pooling_mode = /c\const volatile int pooling_mode = TRANSACTION_POOLING;' bouncer/server.bpf.c"
    else
        echo "Unknown argument to change_mp_bouncer_pool_mode."
        exit -1
    fi
    build_mp_bouncer
}

start_mp_bouncer() {
    ssh -i "aws2022.pem" -f $bouncer_host 'nohup sudo mpbouncer/pgbouncer mpbouncer.ini > /dev/null 2> /dev/null < /dev/null &'
    sleep 5
    ssh -i "aws2022.pem" -f $bouncer_host 'nohup sudo bouncer/mp_bouncer > /dev/null 2> /dev/null < /dev/null &'
    sleep 5
    psql "host=$bouncer_host port=$bouncer_port dbname=benchbase sslmode=disable user=mbutrovi" --command="SELECT 1;" > /dev/null
    sleep 5
}

stop_mp_bouncer() {
    ssh -i "aws2022.pem" $bouncer_host 'sudo kill -2 `pgrep -ox pgbouncer`'
    sleep 5
    ssh -i "aws2022.pem" $bouncer_host 'sudo kill -2 `pgrep -ox mp_bouncer`'
    sleep 5
}

start_mp_mirror() {
    ssh -i "aws2022.pem" $bouncer_host 'cd bouncer && sudo ./start_tc_test.sh'
    sleep 5
    start_mp_bouncer
    psql "host=$bouncer_host port=$bouncer_port dbname=mirror sslmode=disable user=mbutrovi" --command="SELECT 1;" > /dev/null
    sleep 5
}

stop_mp_mirror() {
    ssh -i "aws2022.pem" $bouncer_host 'cd bouncer && sudo ./stop_tc_test.sh'
    sleep 5
    stop_mp_bouncer
}

########################################
### pgbouncer
########################################

get_pgbouncer() {
    ssh -i "aws2022.pem" $bouncer_host 'sudo rm -r pgbouncer || true'

    ssh -i "aws2022.pem" $bouncer_host 'git clone https://github.com/pgbouncer/pgbouncer.git'
    ssh -i "aws2022.pem" $bouncer_host 'cd pgbouncer && git checkout tags/pgbouncer_1_17_0'
    ssh -i "aws2022.pem" $bouncer_host 'cd pgbouncer && git submodule init'
    ssh -i "aws2022.pem" $bouncer_host 'cd pgbouncer && git submodule update'
    ssh -i "aws2022.pem" $bouncer_host 'cd pgbouncer && chmod +x *.sh lib/*.sh lib/mk/*.sh'
    ssh -i "aws2022.pem" $bouncer_host 'cd pgbouncer && ./autogen.sh'
    ssh -i "aws2022.pem" $bouncer_host 'cd pgbouncer && ./configure'
}

build_pgbouncer() {
    ssh -i "aws2022.pem" $bouncer_host 'cd pgbouncer && make clean'
    ssh -i "aws2022.pem" $bouncer_host 'cd pgbouncer && make -j pgbouncer'
}

start_pgbouncer() {
    ssh -i "aws2022.pem" -f $bouncer_host "nohup pgbouncer/pgbouncer pgbouncer.ini > /dev/null 2> /dev/null < /dev/null &"
    sleep 5
    psql "host=$bouncer_host port=$bouncer_port dbname=benchbase sslmode=disable user=mbutrovi" --command="SELECT 1;" > /dev/null
    sleep 5
}

stop_pgbouncer() {
    ssh -i "aws2022.pem" $bouncer_host 'sudo kill -2 `pgrep -ox pgbouncer`'
    sleep 5
}

########################################
### Pgpool-II
########################################

get_pgpool() {
    ssh -i "aws2022.pem" $bouncer_host 'sudo rm -r pgpool-II-4.3.3 || true'

    ssh -i "aws2022.pem" $bouncer_host 'wget https://www.pgpool.net/mediawiki/download.php?f=pgpool-II-4.3.3.tar.gz -O pgpool-II-4.3.3.tar.gz'
    ssh -i "aws2022.pem" $bouncer_host 'tar -xf pgpool-II-4.3.3.tar.gz && rm pgpool-II-4.3.3.tar.gz'
}

build_pgpool() {
    ssh -i "aws2022.pem" $bouncer_host 'cd pgpool-II-4.3.3 && ./configure'
    ssh -i "aws2022.pem" $bouncer_host 'cd pgpool-II-4.3.3 && make -j'
}

start_pgpool() {
    ssh -i "aws2022.pem" -f $bouncer_host "nohup pgpool-II-4.3.3/src/pgpool -n -D -f pgpool.conf -F pcp.conf > /dev/null 2> /dev/null < /dev/null &"
    sleep 5
}

stop_pgpool() {
    ssh -i "aws2022.pem" $bouncer_host 'sudo kill -2 `pgrep -ox pgpool`'
    sleep 5
}

########################################
### Odyssey
########################################

get_odyssey() {
    ssh -i "aws2022.pem" $bouncer_host 'sudo apt -y install postgresql-server-dev-14 cmake'
    ssh -i "aws2022.pem" $bouncer_host 'sudo rm -r odyssey || true'
    ssh -i "aws2022.pem" $bouncer_host 'git clone https://github.com/yandex/odyssey.git'
}

build_odyssey() {
    ssh -i "aws2022.pem" $bouncer_host 'cd odyssey && git checkout tags/1.3'
    ssh -i "aws2022.pem" $bouncer_host 'cd odyssey && make -j local_build'
}

start_odyssey() {
    ssh -i "aws2022.pem" -f $bouncer_host "nohup odyssey/build/sources/odyssey odyssey/odyssey.conf > /dev/null 2> /dev/null < /dev/null &"
    sleep 5
}

stop_odyssey() {
    ssh -i "aws2022.pem" $bouncer_host 'sudo kill -2 `pgrep -ox odyssey`'
    sleep 5
}

send_odyssey_config() {
    scp -i "aws2022.pem" $1 ubuntu@$bouncer_host:./odyssey/odyssey.conf
}

set_odyssey_pool_mode() {
    if [[ $1 == "session" ]]; then
        ssh -i "aws2022.pem" $bouncer_host 'sed -i "/pool \"transaction\"/c\pool \"session\"" odyssey/odyssey.conf'
    elif [[ $1 == "transaction" ]]; then
        ssh -i "aws2022.pem" $bouncer_host 'sed -i "/pool \"session\"/c\pool \"transaction\"" odyssey/odyssey.conf'
    else
        echo "Unknown argument to set_odyssey_pool_mode."
        exit -1
    fi
}

set_odyssey_unix_socket() {
    ssh -i "aws2022.pem" $bouncer_host 'sed -i "/host \"localhost\"/c\# host \"localhost\"" odyssey/odyssey.conf'
    ssh -i "aws2022.pem" $bouncer_host 'sed -i "/unix_socket_dir \"\/var\/run\/postgresql\"/c\unix_socket_dir \"\/var\/run\/postgresql\"" odyssey/odyssey.conf'
    ssh -i "aws2022.pem" $bouncer_host 'sed -i "/unix_socket_mode \"0644\"/c\unix_socket_mode \"0644\"" odyssey/odyssey.conf'
}

set_odyssey_tcp_socket() {
    ssh -i "aws2022.pem" $bouncer_host 'sed -i "/host \"localhost\"/c\host \"localhost\"" odyssey/odyssey.conf'
    ssh -i "aws2022.pem" $bouncer_host 'sed -i "/unix_socket_dir \"\/var\/run\/postgresql\"/c\# unix_socket_dir \"\/var\/run\/postgresql\"" odyssey/odyssey.conf'
    ssh -i "aws2022.pem" $bouncer_host 'sed -i "/unix_socket_mode \"0644\"/c\# unix_socket_mode \"0644\"" odyssey/odyssey.conf'
}


########################################
### BenchBase
########################################

open_idle_postgres_connections() {
    python3 idle_connections_postgres.py $1 $postgres_host $postgres_port benchbase &
    python_pid=$!
    sleep $((num_connections / 60 + 5)) # This was divided by 30 + 5 on the NUCs.
}

close_idle_postgres_connections() {
    process_is_running ${python_pid}
    sudo kill -2 ${python_pid} || true
    while [ $is_running -eq 0 ]
    do
        sleep 10
        process_is_running ${python_pid}
    done
}

get_benchbase() {
    sudo apt -y install openjdk-17-jdk
    sudo rm -r benchbase || true
    git clone https://github.com/mbutrovich/benchbase
    cd benchbase
    git checkout $1
    cd ..
}

build_benchbase() {
    cd benchbase
    ./mvnw clean package -P ${1} -D skipTests
    cd target
    tar -xvf benchbase-${1}.tgz
    cd ../..
}

# Creates and loads the database for the experiment, and runs VACUUM FULL.
load_benchbase() {

    if [[ $3 == "postgres" ]]; then
        psql "host=$postgres_host port=$postgres_port dbname=test sslmode=disable user=mbutrovi" --command="DROP DATABASE IF EXISTS benchbase;"
        psql "host=$postgres_host port=$postgres_port dbname=test sslmode=disable user=mbutrovi" --command="CREATE DATABASE benchbase;"
    fi

    cd ./benchbase/target/benchbase-${3}
    java -jar benchbase.jar -b $1 -c $2 --create=true --load=true --execute=false
    cd ../../..

    if [[ $3 == "postgres" ]]; then
        psql "host=$postgres_host port=$postgres_port dbname=benchbase sslmode=disable user=mbutrovi" --command="VACUUM FULL;"
        psql "host=$postgres_host port=$postgres_port dbname=benchbase sslmode=disable user=mbutrovi" --command="SELECT pg_size_pretty(pg_database_size('benchbase'));"
    fi
}

run_benchbase() {
    rm ./benchbase/target/benchbase-${3}/results/* || true
    cd ./benchbase/target/benchbase-${3}
    java -jar benchbase.jar -b $1 -c $2 --create=false --load=false --execute=true
    cd ../../..
}

change_benchbase_config() {
    xmlstarlet edit --inplace --update $1 --value $2 $3
}

# Assumes get_benchbase() and build_benchbase() already called.
create_benchbase_multiple() {
    for ((i = 0; i < $2; i++))
    do
        cd benchbase/target
        mkdir -p benchbase-${1}-${i}
        tar -xvf benchbase-${1}.tgz -C benchbase-${1}-${i} --strip-components=1
        cd ../..
    done
}

run_benchbase_multiple() {
    for ((i = 0; i < $4; i++))
    do
        rm ./benchbase/target/benchbase-${3}-${i}/results/* || true
        cd ./benchbase/target/benchbase-${3}-${i}
        nohup java -jar benchbase.jar -b $1 -c $2 --create=false --load=false --execute=true > /dev/null 2> /dev/null < /dev/null &
        cd ../../..
    done

    wait
}

get_benchbase_raw_multiple() {
    # # collect results from extra benchbases
    for ((i = 0; i < $5; i++))
    do
        mv ./benchbase/target/benchbase-${4}-${i}/results/*.raw.csv ./results/$1_$2_$3_$i.csv
    done
    csvstack ./results/$1_$2_$3_*.csv > ./results/$1_$2_$3.csv
    rm ./results/$1_$2_$3_*.csv
}

remove_benchbase_multiple() {
    for ((i = 0; i < $2; i++))
    do
        cd benchbase/target
        sudo rm -r benchbase-${1}-${i} || true
        cd ../..
    done
}

########################################
### pg_dump
########################################

run_pg_dump() {
    sudo rm -r /home/ubuntu/pg_dump || true
    sudo mkdir -p /home/ubuntu/pg_dump
    export PGSSLMODE=disable
    export TIME="%E"
    pg_dump_time=$(export PGSSLMODE=disable; export TIME="%E"; /usr/bin/time sudo pg_dump --no-owner --no-privileges --host=${1} --port=${2} --username=mbutrovi --format=directory --file=/home/ubuntu/pg_dump --jobs=20 --table=foo0 --table=foo1 --table=foo2 --table=foo3 --table=foo4 --table=foo5 --table=foo6 --table=foo7 --table=foo8 --table=foo9 --table=foo10 --table=foo11 --table=foo12 --table=foo13 --table=foo14 --table=foo15 --table=foo16 --table=foo17 --table=foo18 --table=foo19 benchbase 2>&1 1>/dev/null)
    # time numactl -N 0 -p 0 sudo PGSSLMODE=disable pg_dump --host=${bouncer_host} --port=${bouncer_port} --username=mbutrovi --format=directory --file=/mnt/nvme0n1/pg_dump --jobs=20 benchbase
}


########################################
### Results
########################################

get_benchbase_txns() {
    (( benchbase_txns = $(wc -l < ./benchbase/target/benchbase-${1}/results/*.raw.csv) - 1 ))
}

get_benchbase_raw() {
    mv ./benchbase/target/benchbase-${4}/results/*.raw.csv ./results/$1_$2_$3.csv
}

get_pgbouncer_txns() {
    # Needs \pset pager off in ~/.psqlrc so it doesn't pause after issuing the SQL command.
    pgbouncer_txns=$(psql "host=$bouncer_host port=$bouncer_port dbname=pgbouncer sslmode=disable mbutrovi" --command="SHOW STATS;" | grep -Po 'benchbase\s*\|\s*\K[0-9]+')
}

########################################
### CSV
########################################

write_csv_value() {
    echo -n $1 >> $2
    echo -n "," >> $2
}

write_csv_line() {
    echo $1 >> $2
}
