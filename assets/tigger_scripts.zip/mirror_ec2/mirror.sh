#!/usr/bin/env bash

set -e
set -u

source common_ec2.sh

mirror_iteration() {
    restore_postgres $postgres_host
    restore_postgres $mirror_host

    if [[ $1 == "pgpool" ]]; then
        start_pgpool
    elif [[ $1 == "mpbouncer" ]]; then
        start_mp_mirror
    fi

    start_cpu_utilization 70 "${3}_${1}_${2}.txt"

    run_benchbase "ycsb" "/home/ubuntu/run_ycsb_proxy.xml" "postgres"

    get_benchbase_raw $3 $1 $2 "postgres"

    if [[ $1 == "pgpool" ]]; then
        stop_pgpool
    elif [[ $1 == "mpbouncer" ]]; then
        stop_mp_mirror
    fi
}

main() {
    set_up_servers

    get_mp_bouncer mirror_wait_64bit mirror_wait_64bit
    send_file $bouncer_host mpbouncer.ini mpbouncer.ini
    build_mp_bouncer

    get_pgpool
    send_file $bouncer_host pcp.conf pcp.conf
    send_file $bouncer_host pgpool.conf pgpool.conf
    build_pgpool

    get_benchbase "no_collector"
    build_benchbase "postgres"

    start_postgres $postgres_host
    load_benchbase "ycsb" "/home/ubuntu/load_ycsb_postgres.xml" "postgres"
    back_up_postgres $postgres_host

    send_remote_file $postgres_host $mirror_host postgres_data.tar postgres_data.tar

    rm -r results || true
    mkdir -p results
    for bouncer in "mpbouncer" "pgpool"
    do
        for iteration in 0 1 2 3 4
        do
            mirror_iteration $bouncer $iteration "ycsb"
        done # end iteration loop
    done # end bouncer loop
}

main
