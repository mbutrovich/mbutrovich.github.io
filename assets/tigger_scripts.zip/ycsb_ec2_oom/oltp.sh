#!/usr/bin/env bash

set -e
set -u

source common_ec2.sh
num_benchbases=25

oltp_iteration() {
    restore_postgres $postgres_host

    if [[ $1 == "pgbouncer" ]]; then
        start_pgbouncer
    elif [[ $1 == "odyssey" ]]; then
        start_odyssey
    elif [[ $1 == "mpbouncer" ]]; then
        start_mp_bouncer
    fi

    if [[ $1 == "none" ]]; then
        run_benchbase_multiple $workload "/home/ubuntu/run_${workload}_postgres.xml" "postgres" $num_benchbases
    else
        run_benchbase_multiple $workload "/home/ubuntu/run_${workload}_proxy.xml" "postgres" $num_benchbases
    fi

    get_benchbase_raw_multiple $workload $bouncer $iteration "postgres" $num_benchbases

    if [[ $1 == "pgbouncer" ]]; then
        stop_pgbouncer
    elif [[ $1 == "odyssey" ]]; then
        stop_odyssey
    elif [[ $1 == "mpbouncer" ]]; then
        stop_mp_bouncer
    fi
    
    stop_postgres $postgres_host
}

main() {
    set_up_servers

    stop_postgres $postgres_host

    get_mp_bouncer bouncer_64bit bench_test_64bit
    send_file $bouncer_host mpbouncer.ini mpbouncer.ini
    change_mp_bouncer_pool_mode "transaction"
    build_mp_bouncer

    get_odyssey
    build_odyssey
    send_file $bouncer_host odyssey_tcp.conf odyssey/odyssey.conf

    get_pgbouncer
    build_pgbouncer
    send_file $bouncer_host pgbouncer_tcp.ini pgbouncer.ini

    get_benchbase "no_collector"
    build_benchbase "postgres"
    create_benchbase_multiple "postgres" $num_benchbases

    rm -r results || true
    mkdir -p results

    for workload in "ycsb"
    do
        start_postgres $postgres_host
        load_benchbase $workload "/home/ubuntu/load_${workload}_postgres.xml" "postgres"
        
        back_up_postgres $postgres_host
        
        for bouncer in "mpbouncer" "pgbouncer" "odyssey" "none"
        do
            for iteration in 0 1 2 3 4
            do
                oltp_iteration $bouncer $iteration $workload
            done # end iteration loop
        done # end bouncer loop
    done # end workload loop
}

main
